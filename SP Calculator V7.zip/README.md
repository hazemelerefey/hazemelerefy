# SP Probability & Statistics Assistant

Introducing the SP Probability & Statistics Assistant — an interactive Jupyter notebook app that helps students learn and practice core probability and introductory statistics concepts.

Built with Python and ipywidgets, the notebook behaves like a lightweight web app while remaining fully transparent and educational. It combines a multi‑tab Probability Calculator (permutations/combinations, basic probability rules, conditional probability, independence, total probability & Bayes) with a Statistics Helper panel that accepts pasted data and returns descriptive measures and a small frequency view.

Author: HazemElErefy

---

## Highlights / Features

- Probability Calculator
  - Permutations P(n, r) and Combinations C(n, r) with input validation and clear error messages
  - Basic probability operations: P(A), P(A ∪ B), P(Aᶜ)
  - Conditional probabilities P(B|A), P(A|B), independent-event intersection P(A ∩ B) = P(A)P(B)
  - Independence checker (with tolerance for floating point rounding)
  - Total probability and Bayes' theorem for a three‑event partition with validations

- Statistics Helper Panel
  - Paste numeric data (comma/space/semicolon/tab separated)
  - Compute population or sample measures: mean (μ / x̄), median, mode(s), range, variance, standard deviation
  - Frequency distribution table and a compact ASCII mini-histogram
  - Helpful validation and human‑friendly error messages

- Polished UI styling (dark theme, soft gradients, 3D header) while ensuring numeric inputs force LTR numerals and tabular lining numerals for clarity.

---

## Files

- `SP Calculator v7.ipynb` — main interactive notebook (Probability Calculator + Statistics Helper)
- `requirements.txt` — suggested Python packages for local setup
- `README.md` — this file
- (Optional) `LICENSE` — MIT recommended if you want to release

---

## Installation (Local)

1. Clone or download the repository that contains `SP Calculator v7.ipynb`.

2. Create and activate a Python virtual environment (recommended):

   - macOS / Linux:
     - python -m venv .venv
     - source .venv/bin/activate
   - Windows:
     - python -m venv .venv
     - .venv\Scripts\activate

3. Install required packages:

   ```
   pip install -r requirements.txt
   ```

4. Launch Jupyter Notebook or JupyterLab:

   ```
   jupyter notebook
   # or
   jupyter lab
   ```

5. Open `SP Calculator v7.ipynb` in your browser and run the cells. The GUI appears inline.

Notes:
- For JupyterLab >= 3, ipywidgets should work out of the box. For older JupyterLab versions, you may need to install lab extensions (see ipywidgets docs).
- If you plan to serve the notebook in shared environments, ensure widget extensions are enabled:
  - jupyter nbextension enable --py widgetsnbextension --sys-prefix

---

## Running in Google Colab

- Colab supports ipywidgets to an extent, but UI/CSS behavior for injected styles may differ. If visual styling is critical, run the notebook locally.
- If using Colab, upload the notebook to your Colab session and run cells. Some interactive behaviors (and custom CSS) may not render identically.

---

## How to use (quick examples)

- Permutations:
  - Enter integer `n` and `r` in the Counting tab and click "Permutations (P(n,r))".
  - The app validates r ≤ n and prints P(n,r) = n! / (n - r)!.

- Basic Probability:
  - Enter favorable and total counts, then click "Calculate P(A)". Or enter probabilities `P(A)`, `P(B)` and `P(A ∩ B)` to compute union or complement.

- Conditional / Independence:
  - Provide `P(A)`, `P(B)`, and `P(A ∩ B)` to compute `P(B|A) = P(A ∩ B)/P(A)` or test independence via the check button.

- Bayes:
  - Fill P(A₁), P(B|A₁), P(A₂), P(B|A₂), P(A₃), P(B|A₃). Use "P(B) (Total Probability)" to compute P(B), then "P(A₁|B) (Bayes)" etc. The notebook checks that P(A₁)+P(A₂)+P(A₃) ≈ 1.

- Statistics Helper:
  - Paste numbers into the data box (e.g. `3, 4.5, 7, 10`) choose "Population" or "Sample", then click "Compute Statistics". Summary, frequency table and mini-histogram are shown.

---

## Developer Notes

- Main UI constructed with ipywidgets (VBox, HBox, Tab, HTML, IntText, FloatText, Button, Textarea, Dropdown).
- Styling is injected as HTML `<style>` inside the notebook for a cohesive dark theme and numeric display enhancements (tabular numbers, enforced LTR for numerals).
- Input validation functions centralize error messaging to the shared output area.
- Floating‑point comparisons use small tolerance (1e-9) for meaningful independence/partition checks.

Suggested improvements:
- Support arbitrary number of partition events for Bayes/total probability (the notebook currently handles 3).
- Add more visual histograms using matplotlib or plotly for richer data visualization.
- Add unit tests for calculation helpers and edge cases.
- Export a static HTML interactive view (nbconvert / voila) for easy sharing.

---

## Accessibility & Formatting

- Inputs force LTR and tabular numerals to avoid numeral rendering issues in mixed-direction documents.
- Color choices and contrast are tuned for long sessions; still ensure to test with real users and accessibility tools.

---

## License & Attribution

- Author: HazemElErefy
- Recommended license: MIT (add `LICENSE` file if releasing publicly)

If you'd like, I can:
- Produce a `LICENSE` file (MIT) and include it here.
- Create a `CONTRIBUTING.md`, tests, or convert the notebook into a standalone web app using Voila.
- Generate a short demo GIF or exported HTML page with usage instructions.
